#! /usr/bin/python

"""
Minimum repo for python script package
"""
import os

def main():

    """
    main
    """
    print("Hello world!")

if __name__ == "__main__":
    main()
